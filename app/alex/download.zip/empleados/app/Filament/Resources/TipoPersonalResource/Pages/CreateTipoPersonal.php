<?php

namespace App\Filament\Resources\TipoPersonalResource\Pages;

use App\Filament\Resources\TipoPersonalResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTipoPersonal extends CreateRecord
{
    protected static string $resource = TipoPersonalResource::class;
}
