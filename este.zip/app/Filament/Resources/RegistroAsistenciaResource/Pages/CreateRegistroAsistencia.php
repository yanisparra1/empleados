<?php

namespace App\Filament\Resources\RegistroAsistenciaResource\Pages;

use App\Filament\Resources\RegistroAsistenciaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRegistroAsistencia extends CreateRecord
{
    protected static string $resource = RegistroAsistenciaResource::class;
}
