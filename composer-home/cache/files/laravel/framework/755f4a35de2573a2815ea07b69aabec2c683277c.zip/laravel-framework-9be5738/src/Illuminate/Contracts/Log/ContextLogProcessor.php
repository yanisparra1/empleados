<?php

namespace Illuminate\Contracts\Log;

use Monolog\Processor\ProcessorInterface;

interface ContextLogProcessor extends ProcessorInterface
{
}
