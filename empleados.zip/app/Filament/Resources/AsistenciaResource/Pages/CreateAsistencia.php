<?php

namespace App\Filament\Resources\AsistenciaResource\Pages;

use App\Filament\Resources\AsistenciaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAsistencia extends CreateRecord
{
    protected static string $resource = AsistenciaResource::class;
}
